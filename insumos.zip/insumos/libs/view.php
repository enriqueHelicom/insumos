<?php 
    class View{
        function __construct(){
            
        }

        function render($nameView){
            require 'views/' . $nameView .'.php';
        }
    }