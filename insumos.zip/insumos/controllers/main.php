<?php 
    class Main extends Controller{

         function __construct() {
            parent::__construct();
            $this -> view -> text = "s";
            $this -> view -> render('main/index');
        }      
}