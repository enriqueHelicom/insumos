<?php 

class notFound{
    function __construct() {
        echo "<p>Error al encontrar el archivo</p>";
    }
}